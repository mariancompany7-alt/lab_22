const createProductBtn = document.querySelector(".createProduct");
const modalOverlay = document.getElementById("modalOverlay");
const closeModalBtn = document.getElementById("closeModal");
const productForm = document.getElementById("productForm");
const productsContainer = document.getElementById("productsContainer");

const categorySelect = document.getElementById("categories");
const searchInput = document.querySelector(".search");
const sortSelect = document.getElementById("sortProducts");

const burgerBtn = document.querySelector(".burgerBtn");
const responsiveForm = document.querySelector(".responsiveForm");

burgerBtn.addEventListener('click', () => {
    burgerBtn.classList.toggle("open");
    responsiveForm.classList.toggle("open");
})

let products = [];
let editIndex = null;

const key = "products";

createProductBtn.addEventListener("click", function () {
    productForm.reset();
    editIndex = null;
    modalOverlay.style.display = "flex";
});

closeModalBtn.addEventListener("click", function () {
    modalOverlay.style.display = "none";
});

modalOverlay.addEventListener("click", function (event) {
    if (event.target === modalOverlay) {
        modalOverlay.style.display = "none";
    }
});

const saveProduct = function () {
    localStorage.setItem(key, JSON.stringify(products));
};

const getProductsFromStorage = function () {
    const data = localStorage.getItem(key);

    if (data) {
        products = JSON.parse(data);
    } else {
        products = [];
    }
};

const createProductCard = function (product, index) {
    const card = document.createElement("div");
    card.classList.add("productCard");

    card.innerHTML = `
            <h2>${product.name}</h2>
            <p class="productDescription">${product.description}</p>
            <p><strong>Price:</strong> ${product.price}$</p>
            <p><strong>Discount:</strong> ${product.discount}%</p>
            <p><strong>In stock:</strong> ${product.stock}</p>
            <p><strong>Category:</strong> ${product.category}</p>
            <img src="${product.image}" class="productImage">
            <div class="productButtons">
                <button class="edit-btn" data-index="${index}">Edit</button>
                <button class="delete-btn" data-index="${index}">Delete</button>
            </div>
        `;

    return card;
};

// Завдання 1 див. index.html

// Завдання 2 і 3 (проміси)

const filterByCategory = function (products) {

    return new Promise(function (resolve) {
        const selectedCategory = categorySelect.value;

        if (!selectedCategory) {
            resolve(products);
            return;
        }

        const result = products.filter(function (product) {
            return product.category.toLowerCase() === selectedCategory.toLowerCase();
        })

        resolve(result);
    })
}

const filterBysearch = function (products) {

    return new Promise(function (resolve) {
        const searchTerm = searchInput.value.trim().toLowerCase();

        if (!searchTerm) {
            resolve(products);
            return;
        }

        const result = products.filter(function (product) {
            const iName = product.name.toLowerCase().includes(searchTerm);
            const inDescription = product.description.toLowerCase().includes(searchTerm);
            return iName || inDescription;
        })

        resolve(result);
    })
}

const sortProducts = function (products) {

    return new Promise(function (resolve) {

        const sortValue = sortSelect.value;
        let result = products.slice();

        if (sortValue === "byEncreasingPrice") {
            result = result.slice().sort(function (a, b) {
                return a.price - b.price;
            })
        }

        if (sortValue === "byDecreasingPrice") {
            result = result.slice().sort(function (a, b) {
                return b.price - a.price;
            })
        }

        if (sortValue === "newestFirst") {
            result = result.slice().sort(function (a, b) {
                return b.id - a.id;
            })
        }

        if (sortValue === "oldestFirst") {
            result = result.slice().sort(function (a, b) {
                return a.id - b.id;
            })
        }

        resolve(result);
    })
}

const renderCards = function () {

    productsContainer.innerHTML = "";
    filterByCategory(products)
        .then(function (afterCategory) {
            return filterBysearch(afterCategory);
        })
        .then(function (afterSearch) {
            return sortProducts(afterSearch);
        })
        .then(function (afterSort) {
            if (afterSort.length === 0) {
                productsContainer.innerHTML = "<p style='padding:20px;color:#888;'>No products found.</p>";
                return;
            }

            afterSort.forEach(function (product) {
                const realIndex = products.indexOf(product);
                const card = createProductCard(product, realIndex);
                productsContainer.appendChild(card);
            });
        })
};

categorySelect.addEventListener('change', () => {
    renderCards();
})

searchInput.addEventListener('input', () => {
    renderCards();
})

sortSelect.addEventListener('change', () => {
    renderCards();
})

getProductsFromStorage();
renderCards();

productForm.addEventListener("submit", function (event) {
    event.preventDefault();

    if (!productForm.checkValidity()) {
        productForm.reportValidity();
        return;
    }

    const product = {
        id: Date.now(),
        name: document.getElementById("productName").value,
        description: document.getElementById("productDescription").value,
        price: Number(document.getElementById("productPrice").value),
        discount: Number(document.getElementById("productDiscount").value),
        stock: Number(document.getElementById("productStock").value),
        category: document.getElementById("productCategory").value,
        image: document.getElementById("productImage").value
    };

    if (editIndex === null) {
        products.push(product);
    } else {
        products[editIndex] = product;
        editIndex = null;
    }

    saveProduct();
    renderCards();

    productForm.reset();
    modalOverlay.style.display = "none";
});

productsContainer.addEventListener("click", function (event) {
    const editBtn = event.target;

    if (editBtn.classList.contains("edit-btn")) {
        const indexValue = editBtn.dataset.index;
        const index = Number(indexValue);

        const product = products[index];

        document.getElementById("productName").value = product.name;
        document.getElementById("productDescription").value = product.description;
        document.getElementById("productPrice").value = product.price;
        document.getElementById("productDiscount").value = product.discount;
        document.getElementById("productStock").value = product.stock;
        document.getElementById("productCategory").value = product.category;
        document.getElementById("productImage").value = product.image;

        editIndex = index;
        modalOverlay.style.display = "flex";
    }
});